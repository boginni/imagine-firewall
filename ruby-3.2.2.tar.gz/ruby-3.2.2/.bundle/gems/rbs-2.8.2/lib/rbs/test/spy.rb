# frozen_string_literal: true

module RBS
  module Test
  end
end
